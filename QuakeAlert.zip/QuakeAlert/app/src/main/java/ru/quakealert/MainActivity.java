package ru.quakealert;
import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(48, 96, 48, 48);
        l.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView t = new TextView(this);
        t.setText("Оповещение о землетрясениях\n\nМониторинг работает в фоне. Источник данных: USGS (магнитуда 4.5+).");
        t.setTextSize(18);
        l.addView(t);

        l.addView(btn("Запустить мониторинг", v -> {
            startForegroundService(new Intent(this, QuakeService.class));
            Toast.makeText(this, "Мониторинг запущен", Toast.LENGTH_SHORT).show();
        }));
        l.addView(btn("ТЕСТ оповещения", v -> {
            Intent i = new Intent(this, AlertActivity.class);
            i.putExtra("title", "ТЕСТ: ЗЕМЛЕТРЯСЕНИЕ");
            i.putExtra("text", "Это проверка системы оповещения. Нажмите ОК, чтобы остановить сигнал.");
            startActivity(i);
        }));
        l.addView(btn("Разрешить показ на экране блокировки", v -> {
            if (Build.VERSION.SDK_INT >= 34 &&
                !getSystemService(NotificationManager.class).canUseFullScreenIntent())
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:" + getPackageName())));
            else Toast.makeText(this, "Уже разрешено", Toast.LENGTH_SHORT).show();
        }));
        l.addView(btn("Отключить экономию батареи", v ->
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())))));
        setContentView(l);
        startForegroundService(new Intent(this, QuakeService.class));
    }
    private Button btn(String s, android.view.View.OnClickListener c) {
        Button b = new Button(this); b.setText(s); b.setOnClickListener(c); return b;
    }
}
