package ru.quakealert;
import android.app.Activity;
import android.media.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class AlertActivity extends Activity {
    AudioManager am; AudioTrack track; Vibrator vib;
    final Handler h = new Handler(Looper.getMainLooper());
    boolean active = true;
    final Runnable keepMax = new Runnable() {
        @Override public void run() {
            if (!active) return;
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
            if (track != null) track.setVolume(1f);
            h.postDelayed(this, 100);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setShowWhenLocked(true); setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        getSystemService(android.app.KeyguardManager.class).requestDismissKeyguard(this, null);

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(0xFFB00020);
        l.setPadding(48, 48, 48, 48);
        TextView t = new TextView(this);
        t.setText("⚠ " + getIntent().getStringExtra("title") + "\n\n" + getIntent().getStringExtra("text")
                + "\n\nУкройтесь: отойдите от окон, встаньте под прочный дверной проём или под стол.");
        t.setTextColor(0xFFFFFFFF); t.setTextSize(24); t.setGravity(Gravity.CENTER);
        Button ok = new Button(this);
        ok.setText("ОК"); ok.setTextSize(28);
        ok.setOnClickListener(v -> { stop(); finish(); });
        l.addView(t);
        l.addView(ok, new LinearLayout.LayoutParams(-1, 220));
        setContentView(l);

        am = getSystemService(AudioManager.class);
        start();
    }

    void start() {
        h.post(keepMax);
        int sr = 44100;
        double[] pat = {0.9, 0.25, 0.9, 0.25};            // сек: звук / пауза / звук / пауза
        int total = 0; for (double d : pat) total += (int) (d * sr);
        short[] buf = new short[total]; int pos = 0;
        for (int p = 0; p < pat.length; p++) {
            int n = (int) (pat[p] * sr);
            for (int k = 0; k < n; k++, pos++) {
                if (p % 2 == 1) { buf[pos] = 0; continue; }
                double a = 2 * Math.PI * k / sr;
                // двухтональный сигнал 853 + 960 Гц (как у CMAS/WEA)
                buf[pos] = (short) (0.5 * (Math.sin(a * 853) + Math.sin(a * 960)) * 32000);
            }
        }
        track = new AudioTrack(
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
                new AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),
                total * 2, AudioTrack.MODE_STATIC, AudioManager.AUDIO_SESSION_ID_GENERATE);
        track.write(buf, 0, total);
        track.setLoopPoints(0, total, -1);
        track.play();
        vib = getSystemService(Vibrator.class);
        vib.vibrate(VibrationEffect.createWaveform(new long[]{0, 900, 250}, 0),
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
    }

    void stop() {
        active = false; h.removeCallbacksAndMessages(null);
        if (track != null) { track.stop(); track.release(); track = null; }
        if (vib != null) vib.cancel();
    }
    @Override public void onBackPressed() { /* блокируем */ }
    @Override public boolean onKeyDown(int c, KeyEvent e) {
        if (c == KeyEvent.KEYCODE_VOLUME_DOWN || c == KeyEvent.KEYCODE_VOLUME_UP) return true;
        return super.onKeyDown(c, e);
    }
    @Override protected void onDestroy() { stop(); super.onDestroy(); }
}
