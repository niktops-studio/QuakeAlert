package ru.quakealert;
import android.app.*;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class QuakeService extends Service {
    static final String FEED = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_hour.geojson";
    final Set<String> seen = new HashSet<>();
    boolean first = true, run = true;
    PowerManager.WakeLock wl;

    @Override public int onStartCommand(Intent i, int f, int id) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("mon", "Мониторинг", NotificationManager.IMPORTANCE_LOW));
        NotificationChannel alert = new NotificationChannel("alert", "Землетрясение", NotificationManager.IMPORTANCE_HIGH);
        alert.setBypassDnd(true);
        alert.setSound(null, null);
        nm.createNotificationChannel(alert);
        Notification n = new Notification.Builder(this, "mon")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("Мониторинг землетрясений активен")
                .setContentText("Приложение следит за новыми событиями").build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        if (wl == null) {
            wl = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "quake:svc");
            wl.acquire();
            new Thread(this::loop).start();
        }
        return START_STICKY;
    }
    void loop() {
        while (run) {
            try { check(); } catch (Exception ignored) {}
            try { Thread.sleep(60_000); } catch (InterruptedException e) { return; }
        }
    }
    void check() throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(FEED).openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(15000);
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
        StringBuilder sb = new StringBuilder(); String s;
        while ((s = r.readLine()) != null) sb.append(s);
        JSONArray arr = new JSONObject(sb.toString()).getJSONArray("features");
        for (int k = 0; k < arr.length(); k++) {
            JSONObject f = arr.getJSONObject(k);
            String id = f.getString("id");
            if (!seen.add(id) || first) continue;
            JSONObject p = f.getJSONObject("properties");
            alert("ЗЕМЛЕТРЯСЕНИЕ! M" + p.optDouble("mag"), p.optString("place"));
        }
        first = false;
    }
    void alert(String title, String text) {
        Intent i = new Intent(this, AlertActivity.class)
                .putExtra("title", title).putExtra("text", text)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "alert")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title).setContentText(text)
                .setCategory(Notification.CATEGORY_ALARM)
                .setFullScreenIntent(pi, true).setContentIntent(pi).build();
        getSystemService(NotificationManager.class).notify((int) System.currentTimeMillis(), n);
        try { startActivity(i); } catch (Exception ignored) {}
    }
    @Override public void onDestroy() { run = false; if (wl != null) wl.release(); }
    @Override public IBinder onBind(Intent i) { return null; }
}
